<script setup>
  import Timer from '../components/Timer.vue';
</script>

<template>
  <main>
    <Timer />
  </main>
</template>
