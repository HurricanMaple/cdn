<script setup>
  import InfoCard from '../components/InfoCard.vue';
</script>

<template>
  <div class="live-container">
    <div class="alert">
      由於直播開啓時間不一，部分直播鏈接可能尚未補上。<br>
      如果鏈接錯誤，請發送郵件至 <a href="mailto://admin@fiee.tk">admin@fiee.tk</a>。
      <br><br>

      實際請以官方爲主。
    </div>

    <h2><b>中國內地</b>地區</h2>
    <InfoCard
      title="湖南衛視跨年晚會"
      hosts="何炅、汪涵、沈夢辰、梁田、靳夢佳、齊思鈞、李莎旻子、小漾、馬萱等。"
      cases="龔俊、王鶴棣、羅一舟、信、黃曉明、李承鉉、陳小春、大張偉、唐伯虎Annie、郝云、周筆暢、Jessica、許嵩、蔡卓妍、鍾欣潼、楊千嬅、蔡程昱、陳立農、龔爽、胡海泉、李慧珍、高曉攀、于文文、王霏霏、周柏豪、蘇有朋、高瀚宇、尹正、娜扎、高亭宇、胡夏、張智霖、王心凌、郁可唯、金晨、范世錡、姚安娜、鄧男子、楊冪、劉戀、楊紫、雷佳、陳冰、許靖韵、檀健次、文吉兒、吳克群、白舉綱、李斯丹妮、林曉峰等。"
      live=""
    />
    <InfoCard
      title="江蘇衛視跨年晚會"
      cases="李宇春、張杰、單依純、盛梅、孫楠、王俊凱、鍾楚曦、張靚穎、周深、薛之謙、張韶涵、楊洪基、劉宇寧、譚詠麟、INTO1劉宇、INTO1林墨、INTO1伯遠、INTO1張嘉元、INTO1劉彰、林允、鄧紫棋、劉維、張藝凡、譚維維、廖昌永、王源、郭冠廷、張常寧、楊瀾、陶建中、黃家倫、陳貝兒、於若飛等。"
      live=""
    />
    <InfoCard
      title="央視 啓航2023 跨年晚會"
      cases="周深、陳偉霆、蕭敬騰、阿雲嘎、郁可唯、歐陽娜娜、白鹿等。"
      live=""
    />
    <InfoCard
      title="浙江衛視跨年晚會"
      cases="李榮浩、楊丞琳、張碧晨、尚雯婕、希林娜依高、Angelababy、鄭愷、沙溢、蔡徐坤、白鹿、關曉彤、王耀慶、GAI周延、胡彥斌、董思成、宋軼、范丞丞、二手玫瑰樂隊、吳莫愁、唐漢霄、張棟梁、王子異、王弦、姚琛、萬妮達、趙馨玥、孟佳、鞠婧禕、曹媛源、鄭迪、柴昀喆、付紹博、孫快快、陳晨、劉子琛、白小白、王赫野等。"
      live=""
    />
    <InfoCard
      title="北京衛視跨年晚會"
      cases="周深、齊秦、郭峰、滿江、沙寶亮、田震、小柯、楊坤、崔健、何冰、郝云、李延亮、趙傳、趙麗娜、新褲子樂隊、劉惜君、GALA樂隊、曹限東、鄧樂軍、邵佳一、徐亮、徐雲龍、楊璞、張路、周寧、阿云嘎、王弦、五洲星海等。"
      live=""
    />
    <InfoCard
      title="Bilibili 最美的夜 跨年晚會"
      cases="金屬啟示錄、艾薇兒、朴冉、張澤、倉木麻衣、法老、鄧紫棋、龔琳娜、宮崎步、郭森、郭雅志、劉憲華、胡沈員、INTO1劉彰、橘子海、劉瑾睿、賴美雲、洛天依、李玉剛、沙一汀、慶怜、石凱、王嘉爾、肖杰、朱海峰、徐均朔、趙兆、鄭闖、朱恩池、周可人、周仕麒、周深等。"
      live="https://www.bilibili.com/bangumi/media/md28340608/"
    />
    <InfoCard
      title="東方衛視跨年晚會"
      cases="毛不易、虞書欣、王一博、趙露思、劉雨昕、程瀟、NAME、黃明昊、李汶翰、老狼、黃雅莉、洪之光、騰格爾、蘇醒、王錚亮、陳楚生、陸虎、張遠、賈乃亮、王櫟鑫、李菲兒、曾黎、任嘉倫等。"
      live=""
    />

    <h2><b>臺灣</b>地區</h2>
    <InfoCard
      title="臺北最嗨新年城"
      hosts="「Lulu」黃路梓茵，搭擋Youtuber布萊克薛薛、阿拉斯"
      cases="蔡健雅、劉若英、玖壹壹、韋禮安、9m88、傻子與白痴、許富凱、彭佳慧 、血肉果汁機、阿爆（阿仍仍）等。"
      live=""
    />
    <InfoCard
      title="SHOW TAOYUAN"
      hosts="黃子佼、宇珊"
      cases="蕭秉治、J.SHEON、鼓鼓（呂思緯）、宇宙人、同理Zunya、Mavis 瑪菲司、白安、熊仔、《原子少年》Ozone、《菱格世代》PINK FUN、Julia吳卓源、丁噹、韓團VIVIZ等。"
      live=""
    />
    <InfoCard
      title="閃耀台中跨年夜"
      hosts="阿 Ken、蔡尚樺、焦凡凡"
      cases="周興哲、林宥嘉、八三夭、畢書盡、W0LF(S) 五堅情、SHAUN、大淵 MUTA、小春Kenzy、天王星、告五人、AcQUA 源少年、陳芳語、鼓鼓呂思緯、徐懷鈺、閻奕格、江惠儀、魏嘉瑩、冰球樂團等。"
      live=""
    />
    <InfoCard
      title="麗寶樂園跨年晚會"
      hosts="小龜、圓圓"
      cases="原子少年天王星、木星、AcQUA 源少年（原子少年）、告五人、旺福樂團、魏嘉瑩、熊仔、麋先生、琳誼、冰球樂團、郭芝吟、江健榆等。"
      live=""
    />
    <InfoCard
      title="高雄亞灣未來市演唱會"
      hosts="浩角翔起、白家綺"
      cases="A-Lin、八三夭、艾怡良、Julia吳卓源、告五人、Ozone（原子少年）、原子少年金星、高爾宣、動力火車、文慧如、滅火器、Kimberley 陳芳語、影子計劃等。"
      live=""
    />
    <InfoCard
      title="花蓮太平洋觀光節 跨年演唱會"
      cases="羅志祥、戴愛玲、FEniX、原子少年土星、白冰冰、舞思愛、莫宰羊、顏佑庭、CTO、黃奕儒、張若凡、Miusa、恐龍偶像、舒比舒比、一好·屴夯、帆家班等。"
      live=""
    />
    <InfoCard
      title="台東 東漂去旅行"
      hosts="陳漢典、咖啡糖賢齡"
      cases="吳青峰、熱狗 MC HotDog、盧廣仲、周湯豪、比莉、家家、Karencici、Matzka、舒米恩、黃玠瑋、Ponay 的原式大樂隊等。"
      live=""
    />
  </div>
</template>

<style scoped>
  h2 {
    margin-left: 12px;
    position: relative;
  }

  h2:before {
    color: #AA334466;
    content: 'HAPPY NEW YEAR !';
    display: inline-block;
    font-family: 'Hanken Grotesk', sans-serif;
    font-size: 24px;
    font-weight: 900;
    line-height: 1;
    position: absolute;
    text-shadow: 4px 0 6px #AA334422;
    z-index: 0;

    top: 4px;
    right: 16px;
  }

  h2:after {
    background-color: #dddddd66;
    content: '';
    position: absolute;
    z-index: -1;

    top: 50%;
    bottom: 10%;
    left: 6px;
    right: 12px;
  }

  h2 b {
    color: #AA3344;
    position: relative;
    text-shadow: 0 0 2px #AA334466;

    top: -6px;
  }

  h2 b:after {
    background: #AA334410;
    content: '';
    position: absolute;

    top: 50%;
    bottom: 10%;
    left: -8px;
    right: -8px;
  }

  .live-container {
    padding-top: 32px;
  }

  .alert {
    border-left: 4px solid #AA3344;
    margin: 16px 4px;
    padding: 8px 16px;
  }

  .alert:before {
    color: #AA3344;
    content: '注意！';
    display: block;
    font-size: 16px;
  }
</style>
